package com.sameerasw.essentials.presentation.components

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import com.sameerasw.essentials.R
import com.sameerasw.essentials.utils.LauncherUtil
import kotlinx.coroutines.delay

/**
 * Blocks access to the rest of the app until Essentials is set as the device's Home/launcher.
 * Polls every second and calls [onBecameDefault] the moment it detects the change, so the
 * caller can swap this out for the real app content automatically - no manual dismissal needed
 * (and none is offered, by design, since the app isn't fully usable until this is done).
 */
@Composable
fun DefaultLauncherGate(onBecameDefault: () -> Unit) {
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        while (true) {
            if (LauncherUtil.isDefaultLauncher(context)) {
                onBecameDefault()
                break
            }
            delay(1000)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 32.dp)
        ) {
            item {
                Text(
                    text = stringResource(R.string.onboarding_title),
                    style = MaterialTheme.typography.title3.copy(fontWeight = FontWeight.Bold),
                    textAlign = TextAlign.Center,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }
            item {
                Text(
                    text = stringResource(R.string.onboarding_body),
                    style = MaterialTheme.typography.body2.copy(fontSize = 12.sp),
                    textAlign = TextAlign.Center,
                    color = Color.LightGray,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }
            item {
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_HOME_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            try {
                                context.startActivity(
                                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (e2: Exception) {}
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = Color.White,
                        contentColor = Color.Black
                    )
                ) {
                    Text(
                        text = stringResource(R.string.onboarding_open_settings),
                        style = MaterialTheme.typography.button.copy(fontSize = 11.sp),
                        textAlign = TextAlign.Center
                    )
                }
            }
            item {
                Text(
                    text = stringResource(R.string.onboarding_waiting),
                    style = MaterialTheme.typography.caption2,
                    textAlign = TextAlign.Center,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 14.dp)
                )
            }
        }
    }
}
