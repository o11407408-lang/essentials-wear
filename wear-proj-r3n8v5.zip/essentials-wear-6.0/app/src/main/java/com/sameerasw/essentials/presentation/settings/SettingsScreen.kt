package com.sameerasw.essentials.presentation.settings

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.ToggleChip
import androidx.wear.compose.material.ToggleChipDefaults
import androidx.wear.compose.material.Switch
import androidx.wear.compose.material.Icon
import androidx.wear.compose.material.Text
import androidx.compose.ui.Alignment
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.google.android.gms.wearable.Wearable
import com.sameerasw.essentials.R
import com.sameerasw.essentials.presentation.components.EssentialsChip
import com.sameerasw.essentials.presentation.components.EssentialsScreen
import com.sameerasw.essentials.presentation.components.EssentialsTitle
import com.sameerasw.essentials.utils.HapticUtil
import com.sameerasw.essentials.utils.ThemeUtil

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val view = LocalView.current
    val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val prefs = context.getSharedPreferences("schedule_prefs", Context.MODE_PRIVATE)

    val hasDndPermission = remember { mutableStateOf(notificationManager.isNotificationPolicyAccessGranted) }
    val hasNotificationPermission = remember {
        mutableStateOf(
            context.checkCallingOrSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    val hasWriteSecureSettings = remember {
        mutableStateOf(
            context.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    val hasNotificationListenerAccess = remember {
        mutableStateOf(
            androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
        )
    }

    val isSyncEnabled = remember { mutableStateOf(prefs.getBoolean("phone_watch_sync_sound_mode_enabled", false)) }
    val isNotificationSoundsEnabled = remember { mutableStateOf(prefs.getBoolean("prefs_notification_sounds_enabled", true)) }
    val isNotificationOverlayEnabled = remember { mutableStateOf(prefs.getBoolean("prefs_notification_overlay_enabled", true)) }
    val isClockBatteryPercentEnabled = remember { mutableStateOf(prefs.getBoolean("prefs_clock_battery_percent_enabled", true)) }

    // Theme color selection state - drives the swatch row below and is written to ThemeUtil immediately on tap
    var colorMode by remember { mutableStateOf(ThemeUtil.getColorMode(context)) }
    var customColor by remember { mutableStateOf(ThemeUtil.getCustomColor(context)) }

    // App-list open method (item 8) and app language (item 10)
    var appDrawerTriggerMode by remember { mutableStateOf(prefs.getString("app_drawer_trigger_mode", "swipe") ?: "swipe") }
    var appLanguage by remember { mutableStateOf(com.sameerasw.essentials.utils.LocaleUtil.getLanguage(context)) }
    val activity = context as? android.app.Activity

    DisposableEffect(Unit) {
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
            when (key) {
                "phone_watch_sync_sound_mode_enabled" -> isSyncEnabled.value = p.getBoolean(key, false)
                "prefs_notification_sounds_enabled" -> isNotificationSoundsEnabled.value = p.getBoolean(key, true)
                "prefs_notification_overlay_enabled" -> isNotificationOverlayEnabled.value = p.getBoolean(key, true)
                "prefs_clock_battery_percent_enabled" -> isClockBatteryPercentEnabled.value = p.getBoolean(key, true)
                "app_drawer_trigger_mode" -> appDrawerTriggerMode = p.getString(key, "swipe") ?: "swipe"
            }
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
        }
    }

    // Refresh permissions when entering/returning (every 2s - no need to hammer this)
    LaunchedEffect(Unit) {
        while (true) {
            hasDndPermission.value = notificationManager.isNotificationPolicyAccessGranted
            hasNotificationPermission.value =
                context.checkCallingOrSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
                        android.content.pm.PackageManager.PERMISSION_GRANTED
            hasWriteSecureSettings.value =
                context.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
                        android.content.pm.PackageManager.PERMISSION_GRANTED
            hasNotificationListenerAccess.value =
                androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
            kotlinx.coroutines.delay(2000)
        }
    }

    val themeColor = ThemeUtil.getThemeColor(context)
    val tonedThemeColor = themeColor?.let {
        Color(ThemeUtil.getTonedColor(it))
    } ?: Color.DarkGray

    val lightAccentColor = themeColor?.let {
        Color(ThemeUtil.getLightAccentColor(it))
    } ?: Color(0xFFB39DDB.toInt())

    EssentialsScreen {
        item {
            EssentialsTitle(
                text = stringResource(R.string.feature_settings),
                color = lightAccentColor
            )
        }

        // Theme Color section
        item {
            Text(
                text = stringResource(R.string.theme_color_label),
                style = androidx.compose.ui.text.TextStyle(
                    fontFamily = com.sameerasw.essentials.presentation.theme.GoogleSansFlexRoundedWide,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    fontSize = 12.sp,
                    color = lightAccentColor
                ),
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
            ) {
                item {
                    SystemColorSwatch(
                        selected = colorMode == ThemeUtil.COLOR_MODE_SYSTEM,
                        onClick = {
                            HapticUtil.performUIHaptic(view)
                            ThemeUtil.setSystemColorMode(context)
                            colorMode = ThemeUtil.COLOR_MODE_SYSTEM
                        }
                    )
                }
                items(ThemeUtil.FIXED_PALETTE) { paletteColor ->
                    FixedColorSwatch(
                        color = Color(paletteColor),
                        selected = colorMode == ThemeUtil.COLOR_MODE_CUSTOM && customColor == paletteColor,
                        onClick = {
                            HapticUtil.performUIHaptic(view)
                            ThemeUtil.setCustomColor(context, paletteColor)
                            colorMode = ThemeUtil.COLOR_MODE_CUSTOM
                            customColor = paletteColor
                        }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
        }

        // Sync Sound Mode Toggle
        item {
            ToggleChip(
                checked = isSyncEnabled.value,
                onCheckedChange = { checked ->
                    HapticUtil.performUIHaptic(view)
                    isSyncEnabled.value = checked
                    prefs.edit().putBoolean("phone_watch_sync_sound_mode_enabled", checked).apply()
                    // Send to phone
                    val nodeClient = Wearable.getNodeClient(context)
                    nodeClient.connectedNodes.addOnSuccessListener { nodes ->
                        val messageClient = Wearable.getMessageClient(context)
                        for (node in nodes) {
                            messageClient.sendMessage(
                                node.id, 
                                "/set_sync_sound_mode", 
                                byteArrayOf(if (checked) 1 else 0)
                            )
                        }
                    }
                },
                label = { Text(stringResource(R.string.toggle_sync_sound_mode), maxLines = 1) },
                appIcon = {
                    Icon(
                        painter = painterResource(id = R.drawable.rounded_volume_up_24),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                },
                toggleControl = {
                    Switch(
                        checked = isSyncEnabled.value,
                        enabled = true
                    )
                },
                colors = ToggleChipDefaults.toggleChipColors(
                    checkedStartBackgroundColor = tonedThemeColor,
                    checkedEndBackgroundColor = tonedThemeColor,
                    uncheckedStartBackgroundColor = tonedThemeColor.copy(alpha = 0.5f),
                    uncheckedEndBackgroundColor = tonedThemeColor.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Notification Alerts Toggle
        item {
            ToggleChip(
                checked = isNotificationSoundsEnabled.value,
                onCheckedChange = { checked ->
                    HapticUtil.performUIHaptic(view)
                    isNotificationSoundsEnabled.value = checked
                    prefs.edit().putBoolean("prefs_notification_sounds_enabled", checked).apply()
                },
                label = { Text(stringResource(R.string.toggle_notification_alerts), maxLines = 1) },
                appIcon = {
                    Icon(
                        painter = painterResource(id = R.drawable.rounded_music_note_24),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                },
                toggleControl = {
                    Switch(
                        checked = isNotificationSoundsEnabled.value,
                        enabled = true
                    )
                },
                colors = ToggleChipDefaults.toggleChipColors(
                    checkedStartBackgroundColor = tonedThemeColor,
                    checkedEndBackgroundColor = tonedThemeColor,
                    uncheckedStartBackgroundColor = tonedThemeColor.copy(alpha = 0.5f),
                    uncheckedEndBackgroundColor = tonedThemeColor.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Show Overlays Toggle
        item {
            ToggleChip(
                checked = isNotificationOverlayEnabled.value,
                onCheckedChange = { checked ->
                    HapticUtil.performUIHaptic(view)
                    isNotificationOverlayEnabled.value = checked
                    prefs.edit().putBoolean("prefs_notification_overlay_enabled", checked).apply()
                },
                label = { Text(stringResource(R.string.toggle_show_overlays), maxLines = 1) },
                appIcon = {
                    Icon(
                        painter = painterResource(id = R.drawable.rounded_mobile_text_2_24),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                },
                toggleControl = {
                    Switch(
                        checked = isNotificationOverlayEnabled.value,
                        enabled = true
                    )
                },
                colors = ToggleChipDefaults.toggleChipColors(
                    checkedStartBackgroundColor = tonedThemeColor,
                    checkedEndBackgroundColor = tonedThemeColor,
                    uncheckedStartBackgroundColor = tonedThemeColor.copy(alpha = 0.5f),
                    uncheckedEndBackgroundColor = tonedThemeColor.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Battery % on Clock Face Toggle
        item {
            ToggleChip(
                checked = isClockBatteryPercentEnabled.value,
                onCheckedChange = { checked ->
                    HapticUtil.performUIHaptic(view)
                    isClockBatteryPercentEnabled.value = checked
                    prefs.edit().putBoolean("prefs_clock_battery_percent_enabled", checked).apply()
                },
                label = { Text(stringResource(R.string.toggle_battery_percent_clock), maxLines = 1) },
                appIcon = {
                    Icon(
                        painter = painterResource(id = R.drawable.rounded_battery_android_frame_full_24),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                },
                toggleControl = {
                    Switch(
                        checked = isClockBatteryPercentEnabled.value,
                        enabled = true
                    )
                },
                colors = ToggleChipDefaults.toggleChipColors(
                    checkedStartBackgroundColor = tonedThemeColor,
                    checkedEndBackgroundColor = tonedThemeColor,
                    uncheckedStartBackgroundColor = tonedThemeColor.copy(alpha = 0.5f),
                    uncheckedEndBackgroundColor = tonedThemeColor.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
        }
        
        item {
            Text(
                text = stringResource(R.string.section_permissions),
                style = androidx.compose.ui.text.TextStyle(
                    fontFamily = com.sameerasw.essentials.presentation.theme.GoogleSansFlexRoundedWide,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    fontSize = 12.sp,
                    color = lightAccentColor
                ),
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        // DND Permission Chip
        item {
            val granted = hasDndPermission.value
            EssentialsChip(
                label = stringResource(R.string.perm_dnd_access_title),
                onClick = {
                    HapticUtil.performUIHaptic(view)
                    if (!granted) {
                        try {
                            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            // Fallback
                        }
                    }
                },
                icon = painterResource(R.drawable.rounded_volume_off_24),
                colors = ChipDefaults.secondaryChipColors(
                    backgroundColor = if (granted) tonedThemeColor else tonedThemeColor.copy(alpha = 0.5f),
                    contentColor = if (granted) Color.White else Color.White.copy(alpha = 0.6f),
                    secondaryContentColor = if (granted) lightAccentColor else Color.White.copy(alpha = 0.4f)
                ),
                border = ChipDefaults.chipBorder(
                    borderStroke = null
                )
            )
        }

        // Post Notifications Permission Chip
        item {
            val granted = hasNotificationPermission.value
            EssentialsChip(
                label = stringResource(R.string.perm_post_alerts_title),
                onClick = {
                    HapticUtil.performUIHaptic(view)
                    if (!granted) {
                        try {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {}
                    }
                },
                icon = painterResource(R.drawable.rounded_mobile_24),
                colors = ChipDefaults.secondaryChipColors(
                    backgroundColor = if (granted) tonedThemeColor else tonedThemeColor.copy(alpha = 0.5f),
                    contentColor = if (granted) Color.White else Color.White.copy(alpha = 0.6f),
                    secondaryContentColor = if (granted) lightAccentColor else Color.White.copy(alpha = 0.4f)
                ),
                border = ChipDefaults.chipBorder(
                    borderStroke = null
                )
            )
        }

        // Write Secure Settings Permission Chip
        item {
            val granted = hasWriteSecureSettings.value
            EssentialsChip(
                label = stringResource(R.string.perm_write_secure_title),
                onClick = {
                    HapticUtil.performUIHaptic(view)
                    if (!granted) {
                        Toast.makeText(context, context.getString(R.string.grant_manually_adb), Toast.LENGTH_LONG).show()
                    }
                },
                icon = painterResource(R.drawable.rounded_lock_24),
                colors = ChipDefaults.secondaryChipColors(
                    backgroundColor = if (granted) tonedThemeColor else tonedThemeColor.copy(alpha = 0.5f),
                    contentColor = if (granted) Color.White else Color.White.copy(alpha = 0.6f),
                    secondaryContentColor = if (granted) lightAccentColor else Color.White.copy(alpha = 0.4f)
                ),
                border = ChipDefaults.chipBorder(
                    borderStroke = null
                )
            )
        }

        // Notification Access Permission Chip - needed for the on-watch notification listener
        item {
            val granted = hasNotificationListenerAccess.value
            EssentialsChip(
                label = stringResource(R.string.perm_notification_access_title),
                onClick = {
                    HapticUtil.performUIHaptic(view)
                    if (!granted) {
                        try {
                            val intent = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {}
                    }
                },
                icon = painterResource(R.drawable.rounded_mobile_text_2_24),
                colors = ChipDefaults.secondaryChipColors(
                    backgroundColor = if (granted) tonedThemeColor else tonedThemeColor.copy(alpha = 0.5f),
                    contentColor = if (granted) Color.White else Color.White.copy(alpha = 0.6f),
                    secondaryContentColor = if (granted) lightAccentColor else Color.White.copy(alpha = 0.4f)
                ),
                border = ChipDefaults.chipBorder(
                    borderStroke = null
                )
            )
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
        }

        // App list open method (item 8)
        item {
            Text(
                text = stringResource(R.string.section_app_drawer),
                style = androidx.compose.ui.text.TextStyle(
                    fontFamily = com.sameerasw.essentials.presentation.theme.GoogleSansFlexRoundedWide,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    fontSize = 12.sp,
                    color = lightAccentColor
                ),
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
        item {
            EssentialsChip(
                label = stringResource(R.string.app_drawer_button),
                onClick = {
                    HapticUtil.performUIHaptic(view)
                    appDrawerTriggerMode = "button"
                    prefs.edit().putString("app_drawer_trigger_mode", "button").apply()
                },
                icon = painterResource(R.drawable.rounded_check_24).takeIf { appDrawerTriggerMode == "button" },
                colors = ChipDefaults.secondaryChipColors(
                    backgroundColor = if (appDrawerTriggerMode == "button") tonedThemeColor else tonedThemeColor.copy(alpha = 0.5f),
                    contentColor = Color.White,
                    secondaryContentColor = lightAccentColor
                ),
                border = ChipDefaults.chipBorder(borderStroke = null)
            )
        }
        item {
            EssentialsChip(
                label = stringResource(R.string.app_drawer_swipe),
                onClick = {
                    HapticUtil.performUIHaptic(view)
                    appDrawerTriggerMode = "swipe"
                    prefs.edit().putString("app_drawer_trigger_mode", "swipe").apply()
                },
                icon = painterResource(R.drawable.rounded_check_24).takeIf { appDrawerTriggerMode == "swipe" },
                colors = ChipDefaults.secondaryChipColors(
                    backgroundColor = if (appDrawerTriggerMode == "swipe") tonedThemeColor else tonedThemeColor.copy(alpha = 0.5f),
                    contentColor = Color.White,
                    secondaryContentColor = lightAccentColor
                ),
                border = ChipDefaults.chipBorder(borderStroke = null)
            )
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Language (item 10)
        item {
            Text(
                text = stringResource(R.string.section_language),
                style = androidx.compose.ui.text.TextStyle(
                    fontFamily = com.sameerasw.essentials.presentation.theme.GoogleSansFlexRoundedWide,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    fontSize = 12.sp,
                    color = lightAccentColor
                ),
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
        item {
            EssentialsChip(
                label = stringResource(R.string.lang_english),
                onClick = {
                    HapticUtil.performUIHaptic(view)
                    if (appLanguage != com.sameerasw.essentials.utils.LocaleUtil.LANG_EN) {
                        com.sameerasw.essentials.utils.LocaleUtil.setLanguage(context, com.sameerasw.essentials.utils.LocaleUtil.LANG_EN)
                        appLanguage = com.sameerasw.essentials.utils.LocaleUtil.LANG_EN
                        activity?.recreate()
                    }
                },
                icon = painterResource(R.drawable.rounded_check_24).takeIf { appLanguage == com.sameerasw.essentials.utils.LocaleUtil.LANG_EN },
                colors = ChipDefaults.secondaryChipColors(
                    backgroundColor = if (appLanguage == com.sameerasw.essentials.utils.LocaleUtil.LANG_EN) tonedThemeColor else tonedThemeColor.copy(alpha = 0.5f),
                    contentColor = Color.White,
                    secondaryContentColor = lightAccentColor
                ),
                border = ChipDefaults.chipBorder(borderStroke = null)
            )
        }
        item {
            EssentialsChip(
                label = stringResource(R.string.lang_russian),
                onClick = {
                    HapticUtil.performUIHaptic(view)
                    if (appLanguage != com.sameerasw.essentials.utils.LocaleUtil.LANG_RU) {
                        com.sameerasw.essentials.utils.LocaleUtil.setLanguage(context, com.sameerasw.essentials.utils.LocaleUtil.LANG_RU)
                        appLanguage = com.sameerasw.essentials.utils.LocaleUtil.LANG_RU
                        activity?.recreate()
                    }
                },
                icon = painterResource(R.drawable.rounded_check_24).takeIf { appLanguage == com.sameerasw.essentials.utils.LocaleUtil.LANG_RU },
                colors = ChipDefaults.secondaryChipColors(
                    backgroundColor = if (appLanguage == com.sameerasw.essentials.utils.LocaleUtil.LANG_RU) tonedThemeColor else tonedThemeColor.copy(alpha = 0.5f),
                    contentColor = Color.White,
                    secondaryContentColor = lightAccentColor
                ),
                border = ChipDefaults.chipBorder(borderStroke = null)
            )
        }
    }
}

/** Circular swatch representing "System" mode: shows a mini rainbow so it never claims to be black/off. */
@Composable
private fun SystemColorSwatch(selected: Boolean, onClick: () -> Unit) {
    val brush = androidx.compose.ui.graphics.Brush.sweepGradient(
        ThemeUtil.FIXED_PALETTE.map { Color(it) }
    )
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(brush)
            .border(
                width = if (selected) 2.dp else 0.dp,
                color = Color.White,
                shape = CircleShape
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                painter = painterResource(id = R.drawable.rounded_check_24),
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = Color.White
            )
        }
    }
}

/** Circular swatch for one of the 10 fixed Material You colors. */
@Composable
private fun FixedColorSwatch(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                width = if (selected) 2.dp else 0.dp,
                color = Color.White,
                shape = CircleShape
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                painter = painterResource(id = R.drawable.rounded_check_24),
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = Color.White
            )
        }
    }
}
