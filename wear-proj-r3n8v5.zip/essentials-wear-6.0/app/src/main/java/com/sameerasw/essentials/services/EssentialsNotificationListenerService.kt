package com.sameerasw.essentials.services

import android.app.Notification
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Base64
import android.util.Log
import com.sameerasw.essentials.utils.NotificationStoreUtil
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * The correct/standard way to read notifications on Android: this sees every notification
 * actually posted to the watch's own system, including ones the OS bridges over from the phone
 * (those still get posted through the watch's local NotificationManager, which is why this works
 * reliably regardless of screen state - unlike the old phone-push-only pipeline). Populates the
 * same storage/broadcast pipeline the Notifications page already reads from.
 */
class EssentialsNotificationListenerService : NotificationListenerService() {
    companion object {
        private const val TAG = "EssentialsNotifListener"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return // ignore our own notifications
            val notification = sbn.notification ?: return

            // Skip group summaries (they duplicate the individual notifications) and bare
            // foreground-service "app is running" notifications, which aren't useful here.
            val isGroupSummary = (notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0
            if (isGroupSummary) return
            if (notification.category == Notification.CATEGORY_SERVICE) return

            val extras = notification.extras
            val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            if (title.isBlank() && text.isBlank()) return

            val isMedia = notification.category == Notification.CATEGORY_TRANSPORT
            val canReply = notification.actions?.any { action ->
                action.remoteInputs?.isNotEmpty() == true
            } ?: false

            val appName = try {
                val pm = packageManager
                val appInfo = pm.getApplicationInfo(sbn.packageName, PackageManager.GET_META_DATA)
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                sbn.packageName
            }

            cacheIconIfNeeded(sbn.packageName)

            val obj = JSONObject().apply {
                put("key", sbn.key)
                put("packageName", sbn.packageName)
                put("appName", appName)
                put("title", title)
                put("text", text)
                put("postTime", sbn.postTime)
                put("isMedia", isMedia)
                put("canReply", canReply)
            }

            NotificationStoreUtil.postNotification(this, obj.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Error handling posted notification", e)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            NotificationStoreUtil.removeNotification(this, sbn.key)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling removed notification", e)
        }
    }

    private fun cacheIconIfNeeded(pkg: String) {
        try {
            val pm = packageManager
            val drawable = pm.getApplicationIcon(pkg)
            val bitmap = if (drawable is BitmapDrawable && drawable.bitmap != null) {
                drawable.bitmap
            } else {
                val size = 96
                val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                drawable.setBounds(0, 0, size, size)
                drawable.draw(canvas)
                bmp
            }
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream)
            val base64 = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
            NotificationStoreUtil.cacheAppIcon(this, pkg, base64)
        } catch (e: Exception) {
            // Icon just won't show for this app - not critical
        }
    }
}
