package com.sameerasw.essentials.presentation

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.wear.compose.navigation.SwipeDismissableNavHost
import androidx.wear.compose.navigation.composable
import androidx.wear.compose.navigation.rememberSwipeDismissableNavController
import com.sameerasw.essentials.presentation.components.DefaultLauncherGate
import com.sameerasw.essentials.presentation.home.HomeScreen
import com.sameerasw.essentials.presentation.navigation.NavRoutes
import com.sameerasw.essentials.presentation.schedule.ScheduleScreen
import com.sameerasw.essentials.presentation.theme.EssentialsTheme
import com.sameerasw.essentials.presentation.yourandroid.YourAndroidScreen
import com.sameerasw.essentials.presentation.settings.SettingsScreen
import com.sameerasw.essentials.utils.LauncherUtil
import com.sameerasw.essentials.utils.LocaleUtil

class MainActivity : ComponentActivity() {

    companion object {
        const val EXTRA_NAVIGATE_TO = "navigate_to"
        const val NAV_SCHEDULE = "schedule"
        const val NAV_YOUR_ANDROID = "your_android"
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleUtil.wrapContext(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setTheme(android.R.style.Theme_DeviceDefault)

        val navigateTo = intent?.getStringExtra(EXTRA_NAVIGATE_TO)

        setContent {
            WearApp(initialScreen = navigateTo)
        }
    }
}

@Composable
fun WearApp(initialScreen: String? = null) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isDefaultLauncher by remember { mutableStateOf(LauncherUtil.isDefaultLauncher(context)) }

    EssentialsTheme {
        if (!isDefaultLauncher) {
            // Blocks everything else until the user sets Essentials as their watch Home -
            // most features (theme, notifications, quick settings) depend on it being active.
            DefaultLauncherGate(onBecameDefault = { isDefaultLauncher = true })
        } else {
            val startDestination = when (initialScreen) {
                MainActivity.NAV_SCHEDULE -> NavRoutes.SCHEDULE
                MainActivity.NAV_YOUR_ANDROID -> NavRoutes.YOUR_ANDROID
                else -> NavRoutes.HOME
            }
            val navController = rememberSwipeDismissableNavController()

            SwipeDismissableNavHost(
                navController = navController,
                startDestination = startDestination
            ) {
                composable(NavRoutes.HOME) {
                    HomeScreen(
                        onNavigate = { route -> navController.navigate(route) }
                    )
                }
                composable(NavRoutes.SCHEDULE) {
                    ScheduleScreen()
                }
                composable(NavRoutes.YOUR_ANDROID) {
                    YourAndroidScreen()
                }
                composable(NavRoutes.SETTINGS) {
                    SettingsScreen()
                }
            }
        }
    }
}
