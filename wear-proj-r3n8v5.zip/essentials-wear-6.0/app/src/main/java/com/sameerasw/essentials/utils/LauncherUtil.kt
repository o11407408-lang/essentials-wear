package com.sameerasw.essentials.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

object LauncherUtil {
    fun isDefaultLauncher(context: Context): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolveInfo = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolveInfo?.activityInfo?.packageName == context.packageName
    }

    /**
     * Best-effort attempt to open the device's own stock/system app list (the "real" app drawer
     * from the OEM, e.g. Samsung/AOSP Wear OS), instead of this app's own grid. Different Wear OS
     * builds ship this under different component names, so we try the known candidates in order
     * and only fall back to our own grid (via [fallback]) if none of them resolve.
     */
    fun openStockAppList(context: Context, fallback: () -> Unit) {
        val candidates = listOf(
            "com.google.android.wearable.app" to "com.google.android.clockwork.home.appslist.AppsListActivity",
            "com.google.android.apps.wearable.settings" to "com.google.android.clockwork.settings.launcher.AppLauncherActivity",
            "com.google.android.wearable.app" to "com.google.android.clockwork.home.launcher.LauncherActivity"
        )
        for ((pkg, cls) in candidates) {
            try {
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    setClassName(pkg, cls)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(intent)
                    return
                }
            } catch (e: Exception) {
                // try next candidate
            }
        }
        // None of the known stock app-list components exist on this device/build - use our own grid.
        fallback()
    }
}
