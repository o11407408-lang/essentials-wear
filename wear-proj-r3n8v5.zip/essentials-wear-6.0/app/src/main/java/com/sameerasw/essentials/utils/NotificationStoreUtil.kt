package com.sameerasw.essentials.utils

import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject

/**
 * Central place that decides whether a notification should actually alert the user right now,
 * and writes it into the same storage/broadcast pipeline the launcher's Notifications page reads
 * from - regardless of whether it came from the on-watch NotificationListenerService or the
 * phone-sync path.
 *
 * Alert rule (as requested): only alert (sound/haptic/overlay) when the watch screen is off, OR
 * when the screen is on and the launcher is showing the clock face. In any other case (inside an
 * app, on Quick Settings/Notifications page, etc.) the notification is still saved silently so it
 * shows up later in the Notifications list, but it won't buzz/pop up.
 */
object NotificationStoreUtil {
    private const val TAG = "NotificationStoreUtil"
    private const val PREFS = "schedule_prefs"
    private const val MAX_STORED = 30

    fun shouldAlertNow(context: Context): Boolean {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val screenOn = powerManager?.isInteractive ?: true
        if (!screenOn) return true

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val onClockFace = prefs.getBoolean("launcher_is_on_clock_face", false)
        return onClockFace
    }

    /**
     * @param notifJson a JSON object string with fields: key, packageName, appName, title, text,
     *                  postTime, isMedia, canReply - matching what the Notifications page expects.
     */
    fun postNotification(context: Context, notifJson: String) {
        try {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val existingJson = prefs.getString("watch_notifications_json", "[]") ?: "[]"
            val jsonArray = JSONArray(existingJson)
            val newObj = JSONObject(notifJson)
            val newKey = newObj.optString("key")

            val updatedArray = JSONArray()
            updatedArray.put(newObj)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                if (obj.optString("key") != newKey && updatedArray.length() < MAX_STORED) {
                    updatedArray.put(obj)
                }
            }
            prefs.edit().putString("watch_notifications_json", updatedArray.toString()).apply()

            val isMedia = newObj.optBoolean("isMedia", false)
            if (isMedia) return // media/transport notifications never alert, only appear in the list

            val isDefaultLauncher = LauncherUtil.isDefaultLauncher(context)
            val alertAllowed = shouldAlertNow(context)
            val overlayEnabled = prefs.getBoolean("prefs_notification_overlay_enabled", true)

            if (alertAllowed) {
                SoundUtil.playNotificationSound(context)
                HapticUtil.performStrongDoubleTap(context)
            }

            if (alertAllowed && overlayEnabled) {
                if (isDefaultLauncher) {
                    context.sendBroadcast(Intent("com.sameerasw.essentials.NOTIFICATIONS_UPDATED").apply {
                        setPackage(context.packageName)
                        putExtra("new_notification_json", notifJson)
                    })
                } else {
                    AccessibilityOverlayUtil.autoEnableAccessibilityService(context)
                    context.sendBroadcast(Intent("com.sameerasw.essentials.SHOW_OVERLAY").apply {
                        setPackage(context.packageName)
                        putExtra("notification_json", notifJson)
                    })
                }
            } else if (isDefaultLauncher) {
                // Not alerting right now, but still let an already-open Notifications page refresh silently.
                context.sendBroadcast(Intent("com.sameerasw.essentials.NOTIFICATIONS_UPDATED").apply {
                    setPackage(context.packageName)
                })
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error storing notification", e)
        }
    }

    fun removeNotification(context: Context, key: String) {
        try {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val existingJson = prefs.getString("watch_notifications_json", "[]") ?: "[]"
            val jsonArray = JSONArray(existingJson)
            val updatedArray = JSONArray()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                if (obj.optString("key") != key) updatedArray.put(obj)
            }
            prefs.edit().putString("watch_notifications_json", updatedArray.toString()).apply()
            context.sendBroadcast(Intent("com.sameerasw.essentials.NOTIFICATIONS_UPDATED").apply {
                setPackage(context.packageName)
            })
        } catch (e: Exception) {
            Log.e(TAG, "Error removing notification", e)
        }
    }

    fun cacheAppIcon(context: Context, packageName: String, iconBase64: String) {
        if (iconBase64.isBlank()) return
        try {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val iconsJson = prefs.getString("watch_app_icons_json", "{}") ?: "{}"
            val iconsObj = JSONObject(iconsJson)
            if (!iconsObj.has(packageName)) {
                iconsObj.put(packageName, iconBase64)
                prefs.edit().putString("watch_app_icons_json", iconsObj.toString()).apply()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error caching app icon", e)
        }
    }
}
