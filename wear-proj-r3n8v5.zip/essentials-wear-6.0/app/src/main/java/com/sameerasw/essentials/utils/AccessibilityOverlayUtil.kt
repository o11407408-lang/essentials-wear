package com.sameerasw.essentials.utils

import android.content.Context
import android.provider.Settings
import android.util.Log
import com.sameerasw.essentials.services.OverlayAccessibilityService

object AccessibilityOverlayUtil {
    private const val TAG = "AccessibilityOverlayUtil"

    /** Requires WRITE_SECURE_SETTINGS (granted via ADB - see the "Write Secure Settings" chip in
     *  Settings). Silently does nothing if it isn't granted; the overlay just won't auto-enable
     *  and the user can still turn it on manually in system Accessibility settings. */
    fun autoEnableAccessibilityService(context: Context) {
        val serviceName = "${context.packageName}/${OverlayAccessibilityService::class.java.name}"
        try {
            val enabledServices = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            if (!enabledServices.contains(serviceName)) {
                val newEnabledServices = if (enabledServices.isEmpty()) serviceName else "$enabledServices:$serviceName"
                Settings.Secure.putString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, newEnabledServices)
                Settings.Secure.putInt(context.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                Log.d(TAG, "Successfully enabled accessibility service: $serviceName")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to enable accessibility service", e)
        }
    }
}
