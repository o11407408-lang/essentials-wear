package com.sameerasw.essentials.utils

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocaleUtil {
    private const val PREFS = "schedule_prefs"
    private const val KEY_LANGUAGE = "app_language" // "en" or "ru"

    const val LANG_EN = "en"
    const val LANG_RU = "ru"

    /** English on first launch, as requested - only becomes Russian if the user explicitly picks it in Settings. */
    fun getLanguage(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LANGUAGE, LANG_EN) ?: LANG_EN
    }

    fun setLanguage(context: Context, lang: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LANGUAGE, lang).apply()
    }

    /** Call from Activity.attachBaseContext(base) as: super.attachBaseContext(LocaleUtil.wrapContext(base)) */
    fun wrapContext(base: Context): Context {
        val lang = getLanguage(base)
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }
}
